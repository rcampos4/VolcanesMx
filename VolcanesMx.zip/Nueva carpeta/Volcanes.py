import numpy as np
import matplotlib.pyplot as plt
import folium
import pandas as pd
from mpl_toolkits.basemap import Basemap

data = pd.read_csv('volcanes.csv')
data.head(28)

maximum = data['Altitud'].max()
minimum = data['Altitud'].min()

maximum, minimum

f, ax = plt.subplots(figsize=(20,8))
ax.set_title('Estados Unidos Mexicanos\n(Radio segun su altura)')
m = Basemap (lat_0=10.,lat_1=3,lon_0=-60.,llcrnrlon=-118.,llcrnrlat=14.,urcrnrlon=-86.,urcrnrlat=34.,resolution='l',projection='lcc')

m.drawparallels(np.arange(10,40,10),labels=[1,0,0,0])
m.drawmeridians(np.arange(-120,-80,10),labels=[0,0,0,1])
m.drawcoastlines()
m.drawcountries(color = 'red')
m.drawstates()
m.fillcontinents(color='coral', alpha=0.3)
for x,y,alt in zip(data['x'].values, data['y'].values, data['Altitud']):
    lng,lat=m(x,y)
    m.scatter(lng,lat, s=np.pi * (6 + (alt-minimum)/(maximum-minimum)*15)**2, marker='o', c='red', alpha=0.7)
ax.annotate(u'\N{COPYRIGHT SIGN} 2017, Pipe', (0, 0))
f.savefig('Volcanes de la Republica Mexicana', dpi=72, transparent=False, bbox_inches='tight')
plt.show()

import folium
#se le asigna un bucle en el cual en vez de hacerlo manualmente este lo haga por medio del bucle.
map_2 = folium.Map(location=[23, -102],zoom_start=4,tiles='Stamen Terrain')

for x,y,alt,nom in zip(data['x'].values, data['y'].values, data['Altitud'], data['Nombre'].values):
    lng,lat=(x,y)
    folium.Marker([lat,lng],popup='Nombre;Altitud').add_to(map_2) 

    map_2.save("map_2.html")
